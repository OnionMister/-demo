﻿//Author:OnionSir

$(function () {
    //导航>
    $(".nav-pre").hover(function () {
        $(".nav-pre").children("div").addClass("nav-pre-show");
    }, function () {
        $(".nav-pre").children("div").removeClass("nav-pre-show");
    });
    $(".nav-cus-service").hover(function () {
        $(".nav-cus-service").children("div").addClass("nav-pre-show");
    }, function () {
        $(".nav-cus-service").children("div").removeClass("nav-pre-show");
    });
    //<导航
    //菜单>
    $(".ban-nav li").hover(function () {
        $(this).css({ "height": "210px" }).siblings().css("height", "30px");
    }, function () {
        $(this).css("height", "30px");
    })
    //<菜单
    //轮播>
    var bannerImg = 0;
    var bannerImgNum = $(".banner-area img").size();
    for (var j = 0; j < bannerImgNum; j++) {
        $(".banner-area-num").append("<li></li>");
    }
    $(".banner-area-num li").eq(0).addClass("on").siblings().removeClass("on");
    $(".banner-area-num li").hover(function () {
        $(this).addClass("on").siblings().removeClass("on");
        $(".banner-area-img").eq($(this).index()).addClass("banner-area-img-opacity").parent().siblings().children().removeClass("banner-area-img-opacity");
    })
    var bannerAuto = setInterval(function () {
        bannerImg++;
        bannerChange();
    }, 3000);
    $(".banner-area").hover(function () {
        clearInterval(bannerAuto);
    }, function () {
        bannerAuto = setInterval(function () {
            bannerImg++;
            bannerChange();
        }, 3000)
    })
    $(".banner-area-btn-lt").click(function () {
        bannerImg--;
        bannerChange();
    })
    $(".banner-area-btn-rt").click(function () {
        bannerImg++;
        bannerChange();
    })
    function bannerChange() {
        if (bannerImg == -1) {
            $(".banner-area-img").eq(bannerImgNum - 1).addClass("banner-area-img-opacity").parent().siblings().children().removeClass("banner-area-img-opacity");
            bannerImg = bannerImgNum - 1;
        }
        if (bannerImg == bannerImgNum) {
            $(".banner-area-img").eq(0).addClass("banner-area-img-opacity").parent().siblings().children().removeClass("banner-area-img-opacity");
            bannerImg = 0;
        }
        $(".banner-area-img").eq(bannerImg).addClass("banner-area-img-opacity").parent().siblings().children().removeClass("banner-area-img-opacity");
        $(".banner-area-num li").eq(bannerImg).addClass("on").siblings().removeClass("on");
    }
    //<轮播
    //公告&促销切换>
    $(".ann-tab p").hover(function () {
        $(this).addClass("mouse-hover").siblings().removeClass("mouse-hover");
        $(".tab-con").eq($(this).index()).addClass("tab-con-show").siblings().removeClass("tab-con-show");
    })

    //<公告&促销切换
});