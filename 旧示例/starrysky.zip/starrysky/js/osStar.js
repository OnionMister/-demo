﻿//星辰特效
"use strict";
var canvas = document.getElementById('starCanvas'),
  ctx = canvas.getContext('2d'),
  w = canvas.width = window.innerWidth,
  h = canvas.height = window.innerHeight,

  hue = 217,            //星星颜色色调（hsl色系）（范围：0~360）
  stars = [],           //存放渲染星星
  count = 0,            //作为stars数组的下标，实现随机控制星辰速度
  maxStars = 1300;      //星星数量

var osStarCvs = document.createElement('canvas'),//用于绘制星辰
  ctx2 = osStarCvs.getContext('2d');
osStarCvs.width = 100;
osStarCvs.height = 100;
var half = osStarCvs.width / 2,
  gradient2 = ctx2.createRadialGradient(half, half, 0, half, half, half);  //创建线性背景（星辰）
//设置各区域颜色
gradient2.addColorStop(0.03, '#CCC');
//采用hsl色系（色调、饱和度、亮度），可查找hsl色系表更换颜色，也可是使用rgba色系（rgb色+透明度）
gradient2.addColorStop(0.1, 'hsl(' + hue + ', 61%, 33%)');
gradient2.addColorStop(0.3, 'hsl(' + hue + ', 64%, 6%)');
gradient2.addColorStop(1, 'transparent');
//画布填充
ctx2.fillStyle = gradient2;
//绘制路径（圆）
ctx2.beginPath();
ctx2.arc(half, half, half, 0, Math.PI * 2);
ctx2.fill();


function random(min, max) {
    if (arguments.length < 2) {
        max = min;
        min = 0;
    }

    if (min > max) {
        var hold = max;
        max = min;
        min = hold;
    }
    //获得随机数，并返回小于等于其的最大整数
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function maxOrbit(x, y) {
    var max = Math.max(x, y),
      diameter = Math.round(Math.sqrt(max * max + max * max));
    return diameter / 2;
    //星星移动范围，值越大范围越小，
}
var Star = function () {  //把星星及相关属性放入数组
    //星星大小
    this.orbitRadius = random(maxOrbit(w, h));
    this.radius = random(60, this.orbitRadius) / 8;
    this.orbitX = w / 2;
    this.orbitY = h / 2;
    this.timePassed = random(0, maxStars);
    //星星移动速度
    this.speed = random(this.orbitRadius) / 50000;
    this.alpha = random(2, 10) / 10;
    count++;
    stars[count] = this;
}

Star.prototype.draw = function () {  //绘制星星
    var x = Math.sin(this.timePassed) * this.orbitRadius + this.orbitX,
      y = Math.cos(this.timePassed) * this.orbitRadius + this.orbitY,
      twinkle = random(10);

    if (twinkle === 1 && this.alpha > 0) {
        this.alpha -= 0.05;
    } else if (twinkle === 2 && this.alpha < 1) {
        this.alpha += 0.05;
    }

    ctx.globalAlpha = this.alpha;
    ctx.drawImage(osStarCvs, x - this.radius / 2, y - this.radius / 2, this.radius, this.radius);
    this.timePassed += this.speed;
}

for (var i = 0; i < maxStars; i++) {  //所有星星放入数组
    new Star();
}

function animation() {
    //在目标图像（星辰）上绘制源图像（移动残影）
    ctx.globalCompositeOperation = 'source-over';
    //这是透明度基数（后续设置的透明度要乘以该基数）
    ctx.globalAlpha = .5;
    //填充颜色透明度为1*0.5
    ctx.fillStyle = 'hsla(' + hue + ', 64%, 6%, 1)';
    //方法绘制“已填色”的矩形,其实坐标（0,0），宽为：w，高位h
    ctx.fillRect(0, 0, w, h)
    //显示源图像和目标图像
    ctx.globalCompositeOperation = 'lighter';
    //绘制所有星星
    for (var i = 1, l = stars.length; i < l; i++) {
        stars[i].draw();
    };
    //定时回调。由系统屏幕刷新频率（Hz）来决定回调函数的执行时机,时间为1000/屏幕刷新率
    window.requestAnimationFrame(animation);
}
animation();